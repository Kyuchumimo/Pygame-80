<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.2" name="0" tilewidth="8" tileheight="8" tilecount="256" columns="16">
 <image source="0.png" width="128" height="128"/>
</tileset>
